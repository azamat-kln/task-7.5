import java.util.Scanner

val scanner = Scanner(System.`in`)

fun main() {

    val point1 = Point(scanner.nextDouble(), scanner.nextDouble())
    val point2 = Point(scanner.nextDouble(), scanner.nextDouble())
    val point3 = Point(scanner.nextDouble(), scanner.nextDouble())

    val myTriangle = Triangle(point1, point2, point3)
    myTriangle.print()

    myTriangle.perimeter().also {
        println("Perimeter: $it")
    }

    myTriangle.area().also {
        println("Area: $it")
    }

}