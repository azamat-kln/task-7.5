import java.util.*
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

class Triangle(
    private val vertex1: Point,
    private val vertex2: Point,
    private val vertex3: Point
) {

    fun print() {
        // some triangle description
        println("x: ${vertex1.x} y: ${vertex1.y}")
        println("x: ${vertex2.x} y: ${vertex2.y}")
        println("x: ${vertex3.x} y: ${vertex3.y}")
    }

    fun perimeter(): Double {
        val lengthX1 = abs(vertex2.x - vertex1.x).pow(2)
        val lengthY1 = abs(vertex2.y - vertex1.y).pow(2)
        val sum1 = sqrt(lengthX1 + lengthY1)

        val lengthX2 = abs(vertex3.x - vertex2.x).pow(2)
        val lengthY2 = abs(vertex3.y - vertex2.y).pow(2)
        val sum2 = sqrt(lengthX2 + lengthY2)

        val lengthX3 = abs(vertex1.x - vertex3.x).pow(2)
        val lengthY3 = abs(vertex1.y - vertex3.y).pow(2)
        val sum3 = sqrt(lengthX3 + lengthY3)

        return sum1 + sum2 + sum3
    }

    fun area(): Double {
        val sumXY1: Double = (vertex1.x - vertex3.x) * (vertex2.y - vertex3.y)
        val sumXY2: Double = (vertex2.x - vertex3.x) * (vertex1.y - vertex3.y)
        return abs(sumXY1 - sumXY2) / 2
    }
}

class Point(val x: Double, val y: Double) {

    fun isCollinear(): Boolean {
        if (x == 0.0 || y == 0.0) return true
        return false
    }

}